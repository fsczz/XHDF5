===============================================
:mod:`XRootD.client.CopyProcess`: Copying files
===============================================

Class Reference
---------------

.. module:: XRootD.client
   :noindex:

.. autoclass:: XRootD.client.CopyProcess

Methods
*******

.. automethod:: XRootD.client.CopyProcess.add_job
.. automethod:: XRootD.client.CopyProcess.prepare
.. automethod:: XRootD.client.CopyProcess.run

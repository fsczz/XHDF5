rm -rf *.o *.so
rm -rf H5OpenXrd
make
cp libXrdExtHttp.so /home/fsc